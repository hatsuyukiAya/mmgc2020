function toShow(){
    window.location.href = "/zh/Show";
}
function toIntroduction() {
    window.location.href = "/zh/Introduction";
}
function toIndex() {
    window.location.href = "/"
}
function toAbout() {
    window.location.href = "/zh/About"
}

/**
 * jp
 */
function toShowJp(){
    window.location.href = "/jp/Show";
}
function toIntroductionJp() {
    window.location.href = "/jp/Introduction";
}
function toIndexJp() {
    window.location.href = "/"
}
function toAboutJp() {
    window.location.href = "/jp/About"
}