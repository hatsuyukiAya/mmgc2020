
/**
 *  侧栏导航索引
 */
let contentIndex = 0;

/**
 *  更新侧栏导航样式
 *  @contentIndex 侧栏导航当前索引
 */
function loadRightNavi(contentIndex){

    // 圆圈展开样式
    let onmouseoverBind = (circles,i) => {
        return function () {
            circles[i].style.width = "110px";
            circles[i].style.height = "110px";
            circles[i].style.opacity = "100%";
        }
    }
    // 圆圈收起样式
    let onmouseleaveBind = (circles,i) => {
        return function () {
            circles[i].style.width = "0px";
            circles[i].style.height = "0px";
            circles[i].style.opacity = "0%";
        }
    }

    // 获取圆圈
    let circles = document.getElementsByClassName("circle");
    // 获取navi节点
    let naviNodes = document.getElementsByClassName("naviNode");

    // 遍历navi节点 更新样式
    for(let i=0;i<naviNodes.length;i++){

        // 判断i是否为当前索引
        if(i == contentIndex){
            // 当前页

            // 给naviNode添加class index1 无需手动判断 存在则不会再添加
            naviNodes[i].classList.add("index1");
            // 移除原先添加过的鼠标事件
            naviNodes[i].onmouseover = function () {

            };
            naviNodes[i].onmouseleave = function () {

            };


            // 改变circle默认样式
            circles[i].style.width = "110px";
            circles[i].style.height = "110px";
            circles[i].style.opacity = "100%";


        } else {
            // 非当前索引

            // 给naviNode删除class index1
            naviNodes[i].classList.remove("index1");

            // 添加circle鼠标事件
            naviNodes[i].onmouseover = onmouseoverBind(circles,i);
            naviNodes[i].onmouseleave = onmouseleaveBind(circles,i);

            // 改变circle默认样式
            circles[i].style.width = "0px";
            circles[i].style.height = "0px";
            circles[i].style.opacity = "0%";

        }
    }
}




// 初始化
window.onload = function () {
    // 生成右侧导航
    loadRightNavi(contentIndex);

    // 鼠标滚轮事件
    onmousewheel = function (event) {
        // event.preventDefault();
        event = event || window.event;
        // 判断鼠标滚动方向
        // 向上滚正数 向下滚负数
        if (event.wheelDelta > 0){
            // 向上滚
            // 根据当前位置切换锚点
            // 获取当前滚轮位置
            let scrollTop = document.documentElement.scrollTop;
            // 获取section高度
            let height = document.getElementsByTagName('section')[0].offsetHeight;
            // 判断当前滚轮位置是否与侧栏对应 不对应则更新
            if(scrollTop < height*contentIndex + height / 2 || scrollTop > height + height / 2){
                // 更新锚点
                // 判断当前滚轮位置所属的锚点 滚轮位置 / section高度 向下取整
                loadRightNavi(Math.floor(scrollTop / height));
                // 更新contentIndex
                contentIndex = Math.floor(scrollTop / height);
            }

        }
        if (event.wheelDelta < 0){
            // 向下滚
            // 根据当前位置切换锚点
            // 获取当前滚轮位置
            let scrollTop = document.documentElement.scrollTop;
            // 获取section高度
            let height = document.getElementsByTagName('section')[0].offsetHeight;
            // 判断当前滚轮位置是否与侧栏对应 不对应则更新
            if(scrollTop < height*contentIndex + height / 2 || scrollTop > height + height / 2){
                // 更新锚点
                // 判断当前滚轮位置所属的锚点 滚轮位置 / section高度 向下取整
                loadRightNavi(Math.ceil(scrollTop / height));
                // 更新contentIndex
                contentIndex = Math.floor(scrollTop / height);
            }
        }
    };
};
// 赛事介绍锚点事件
function rollContestAbout(){
    document.querySelector('#contestAbout').scrollIntoView({ behavior: 'smooth' });
    contentIndex = 0;
    loadRightNavi(0); // 重新载入右侧
}
// 参赛资格锚点事件
function rollQualification() {
    document.querySelector('#qualification').scrollIntoView({ behavior: 'smooth' });
    contentIndex = 1;
    loadRightNavi(1); // 重新载入右侧
}
// 交稿相关锚点事件
function rollDelivery() {
    document.querySelector('#delivery').scrollIntoView({ behavior: 'smooth' });
    contentIndex = 2;
    loadRightNavi(2); // 重新载入右侧
}
// 翻译相关锚点事件
function rollTranslate() {
    document.querySelector('#translate').scrollIntoView({ behavior: 'smooth' });
    contentIndex = 3;
    loadRightNavi(3); // 重新载入右侧
}

// 封装事件绑定
function bind(obj,eventStr,callback) {
    if(obj.addEventListener){
        // 大部分浏览器兼容
        obj.addEventListener(eventStr,callback,false);
    } else {
        // IE8以下
        obj.attachEvent("on"+eventStr, function () {
            callback.call(obj)
        })
    }
}