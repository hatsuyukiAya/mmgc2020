
const express = require('express');
const router = express.Router();


router.get('/Introduction',(req, res) => {
    res.type('.html');
    res.sendFile(__dirname + '/public/jp/Introduction.html');
});

router.get('/Show',(req, res) => {
    res.type('.html');
    res.sendFile(__dirname + '/public/jp/Show.html');
});


router.get('/About',(req, res) => {
    res.type('.html');
    res.sendFile(__dirname + '/public/jp/About.html');
});

module.exports = router;