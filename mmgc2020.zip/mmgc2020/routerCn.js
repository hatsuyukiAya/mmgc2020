
const express = require('express');
const router = express.Router();


router.get('/Introduction',(req, res) => {
    res.type('.html');
    res.sendFile(__dirname + '/public/zh/Introduction.html');
});

router.get('/Show',(req, res) => {
    res.type('.html');
    res.sendFile(__dirname + '/public/zh/Show.html');
});

router.get('/Show',(req, res) => {
    res.type('.html');
    res.sendFile(__dirname + '/public/zh/Show.html');
});

router.get('/About',(req, res) => {
    res.type('.html');
    res.sendFile(__dirname + '/public/zh/About.html');
});

module.exports = router;